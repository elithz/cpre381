#include <stdlib.h>

using namespace std

main()
{
	int x=1,y=1;
	for (double i=0; i<1000000; i++)
	{
		
