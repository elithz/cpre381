#include <stdio.h>
int main()
{
   int array[50], n, c, d, position, swap;
   n = 50;
   for ( c = 0 ; c < n ; c++ )
      array[c] = rand();
 
   for ( c = 0 ; c < ( n - 1 ) ; c++ )
   {
      position = c;
 
      for ( d = c + 1 ; d < n ; d++ )
      {
         if ( array[position] > array[d] )
            position = d;
      }
      if ( position != c )
      {
         swap = array[c];
         array[c] = array[position];
         array[position] = swap;
      }
   }
   return 0;
}